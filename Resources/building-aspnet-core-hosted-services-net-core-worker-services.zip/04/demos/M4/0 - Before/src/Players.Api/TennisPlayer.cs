namespace Players.Api
{
    public class TennisPlayer
    {
        public int Id { get; set; }

        public string Forename { get; set; }

        public string Surname { get; set; }
    }
}
