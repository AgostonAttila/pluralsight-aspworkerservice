﻿namespace TennisBookings.ResultsProcessing.ExternalServices.Statistics
{
    public class StatisticsApiClientOptions
    {
        public string BaseAddress { get; set; }
    }
}
