﻿namespace TennisBookings.Web.Configuration
{
    public class ContentConfiguration : IContentConfiguration
    {
        public bool CheckForProfanity { get; set; }
    }
}
