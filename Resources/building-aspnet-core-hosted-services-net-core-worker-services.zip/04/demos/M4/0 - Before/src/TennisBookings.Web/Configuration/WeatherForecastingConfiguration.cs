﻿namespace TennisBookings.Web.Configuration
{
    public class WeatherForecastingConfiguration
    {
        public bool EnableWeatherForecast { get; set; }
    }
}
