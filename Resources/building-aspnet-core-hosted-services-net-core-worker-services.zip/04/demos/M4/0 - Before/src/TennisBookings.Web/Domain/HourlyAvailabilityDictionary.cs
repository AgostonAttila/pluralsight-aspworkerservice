﻿using System.Collections.Generic;

namespace TennisBookings.Web.Domain
{
    public class HourlyAvailabilityDictionary : Dictionary<int, Dictionary<int, bool>>
    {

    }
}
