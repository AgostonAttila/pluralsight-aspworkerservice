﻿namespace TennisBookings.Web.Domain
{
    public interface IMembershipAdvert
    {
        decimal OfferPrice { get; }
        decimal Saving { get; }
    }
}